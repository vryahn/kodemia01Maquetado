# Desafío 2. Koders maquetadores profesionales 2022

Desafío con Bootstrap

## Comenzando 🚀

Para empezar, ps corre el index y listo ahi jala todo we

### Pre-requisitos 📋

Una compu que no se te trabe, conexión a github para obtener el código y así, etcétera

## Construido con 🛠️

HTML, CSS, SASS y Bootstrap (o eso creo yo)

## Versionado 📌

Esta es la versión final final, pero puede haber una versión final final final. Así es la vida :P

## Licencia 📄

Es OpenSource porque soy buenas ondas
